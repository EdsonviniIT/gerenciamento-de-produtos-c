# Guia de estudo — Sistema de Gerenciamento de Produtos em C

GUIA DE ESTUDO — SISTEMA DE GERENCIAMENTO DE PRODUTOS EM C

1. VISÃO GERAL
O programa gerencia até 100 produtos. Cada produto tem ID, nome, categoria,
preço, quantidade e fornecedor. Os produtos ficam em um vetor de estruturas
na memória e são armazenados entre execuções no arquivo produtos.csv.

Para executar:
- Coloque sistema_produtos.c e produtos.csv na mesma pasta.
- Compile: gcc sistema_produtos.c -o sistema_produtos
- Execute no Linux/macOS: ./sistema_produtos
- No Windows (MinGW): sistema_produtos.exe

O CSV usa ponto e vírgula como separador. Ao digitar preço, use ponto decimal:
49.90, não 49,90. Para manter o formato simples, não use ponto e vírgula nos
campos de texto (nome, categoria e fornecedor).

2. STRUCT
struct Produto {
    int id;
    char nome[50];
    char categoria[50];
    float preco;
    int quantidade;
    char fornecedor[50];
};

struct define um tipo composto. Em vez de manter cada dado em variáveis
separadas, agrupamos os campos que descrevem um produto.

3. VETOR DE STRUCT
struct Produto lista[MAX_PRODUTOS];

Cria um vetor com espaço para 100 estruturas Produto. A primeira posição é
lista[0], a segunda é lista[1], e assim por diante. O ID é um identificador
do produto; o índice é apenas a posição dele no vetor. Não são a mesma coisa.

4. QUANTIDADE
A variável quantidade informa quantos elementos do vetor estão ocupados.
Se quantidade vale 2, os produtos cadastrados estão em lista[0] e lista[1].
MAX_PRODUTOS é a capacidade máxima; quantidade é o total efetivamente usado.

5. FUNÇÕES E PARÂMETROS
O programa separa tarefas em funções:
- cadastrarProduto: recebe o vetor e um ponteiro para quantidade.
- listarProdutos: recebe o vetor e a quantidade.
- pesquisarProduto: permite procurar por ID, nome, categoria ou preço.
- alterarProduto: modifica os campos de um produto.
- excluirProduto: remove um produto do vetor.
- salvarCSV e carregarCSV: escrevem e leem o arquivo.
- mostrarMenu: imprime as opções.
- main: coordena o programa.

Uma função void executa uma tarefa sem devolver um valor. Uma função int,
como buscarIndicePorID, devolve um inteiro: a posição encontrada ou -1.

6. POR QUE ALGUMAS FUNÇÕES RECEBEM struct Produto lista[]?
Em parâmetros de função, um vetor é recebido como acesso aos elementos do
vetor original. Assim, a função pode consultar e modificar os produtos.
Exemplo: lista[indice].preco = novoPreco;

7. PONTEIROS E &
O parâmetro int *quantidade é um ponteiro para a variável quantidade original.
Na chamada cadastrarProduto(lista, &quantidade), o & obtém o endereço dessa
variável. Dentro da função, *quantidade acessa o valor original.
Isso permite que a função aumente ou diminua a quantidade de produtos e que
a alteração seja percebida pelo main.

Diferença:
- quantidade: o valor inteiro.
- &quantidade: o endereço da variável.
- int *quantidade: declara um ponteiro para inteiro.
- *quantidade: acessa o valor guardado no endereço apontado.

8. OPERADOR -> E STRUCT
O programa usa mostrarUmProduto(struct Produto p), que recebe uma cópia e
acessa os campos com p.id e p.nome.
Se a função recebesse struct Produto *p, seria um ponteiro e os campos seriam
acessados com p->id e p->nome.
O operador -> é uma forma abreviada de (*p).campo.

9. PESQUISA POR CARACTERÍSTICAS
A função pesquisarProduto apresenta um submenu para pesquisar por ID, nome,
categoria ou preço. A busca por ID usa buscarIndicePorID, que percorre o vetor
com for e devolve a posição encontrada ou -1. As buscas por nome e categoria
usam strstr para encontrar um trecho de texto. A busca por preço compara o
valor informado com o preço cadastrado usando uma pequena tolerância, pois
números float podem ter pequenas diferenças de representação.

10. EXCLUSÃO
Ao excluir, o programa não deixa um “buraco” no vetor. Ele desloca cada
elemento posterior uma posição para trás:
lista[i] = lista[i + 1];
Depois reduz quantidade em uma unidade. O último elemento lógico deixa de
fazer parte dos dados cadastrados.

11. ARQUIVOS E CSV
FILE *arquivo representa o arquivo aberto.
fopen(ARQUIVO_CSV, "r") abre para leitura.
fopen(ARQUIVO_CSV, "w") abre para escrita e substitui o conteúdo anterior.
fprintf escreve linhas no CSV.
fgets lê uma linha.
fclose fecha o arquivo e libera o recurso.

O CSV é texto organizado em colunas. A primeira linha contém os cabeçalhos.
As demais linhas representam produtos. carregarCSV converte cada campo de
texto para o tipo correspondente e preenche o vetor.

12. STRINGS
Em C, textos são vetores de char terminados por '\0'.
fgets lê texto com limite de tamanho.
strcpy copia uma string (no programa inicial de exemplo).
strncpy copia com limite máximo.
strtok separa uma linha em campos usando ';'.
strcspn é usado para localizar a quebra de linha e removê-la.

13. ENTRADA DE DADOS
lerTexto usa fgets para ler nomes e textos.
lerInteiro usa strtol para converter texto em inteiro.
lerFloat usa strtof para converter texto em número decimal.
Isso evita misturar scanf e fgets e ajuda a validar entradas numéricas.

14. MENU, DO-WHILE E SWITCH
do { ... } while (opcao != 0) repete o menu pelo menos uma vez e continua
enquanto o usuário não escolher zero.
switch(opcao) escolhe qual operação executar:
case 1 cadastra, case 2 lista, case 3 pesquisa, case 4 altera,
case 5 exclui, case 6 salva e case 0 salva e encerra.
break impede que a execução continue para o próximo case.

15. COMO EXPLICAR O FLUXO AO PROFESSOR
1. O main cria o vetor e a variável quantidade.
2. carregarCSV tenta recuperar os produtos salvos.
3. O menu é exibido dentro de um do-while.
4. O switch identifica a opção digitada.
5. A função correspondente realiza a operação.
6. As alterações são salvas no CSV.
7. A opção zero salva e encerra o programa.

16. LIMITAÇÕES DIDÁTICAS IMPORTANTES
- O sistema tem limite de 100 produtos.
- Campos de texto não podem conter ';' porque esse caractere separa colunas.
- O preço deve ser digitado com ponto decimal.
- O CSV é um formato simples; não implementa regras completas de CSV com
  aspas, separadores dentro dos campos ou tratamento de caracteres especiais.
- O exemplo é adequado para estudo e apresentação acadêmica, não é um sistema
  comercial pronto para uso.
- Em uma evolução futura, pode-se validar melhor entradas, confirmar exclusões,
  permitir busca por nome/categoria e separar o projeto em vários arquivos.

17. PERGUNTAS QUE O PROFESSOR PODE FAZER
P: Qual a diferença entre struct e vetor?
R: struct agrupa campos de um produto; vetor armazena vários produtos.

P: Qual a diferença entre ID e índice?
R: ID identifica o produto; índice indica sua posição no vetor.

P: Por que passar &quantidade?
R: Para a função receber o endereço e conseguir alterar a variável original.

P: Para que serve return -1 na busca?
R: Indica que o ID não foi encontrado.

P: Por que usar arquivo CSV?
R: Para manter os dados depois que o programa é encerrado.

P: O que faz do-while?
R: Repete o menu até a opção de saída ser escolhida.

P: O que faz switch?
R: Direciona a execução conforme a opção escolhida.

P: Por que usar funções?
R: Para dividir o programa em tarefas menores, facilitar leitura, teste e manutenção.
